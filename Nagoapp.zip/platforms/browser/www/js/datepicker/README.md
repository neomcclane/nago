jquery-mobile-datepicker-wrapper
================================

Wrapper to turn jquery ui datepicker into a mobile widget.

This takes the jQuery ui datepicker and turns it into a fully functional jquery mobile widget. This includes auto initalization via data-role="date" and reading of options from data-attributes.
For example usage please see http://jsbin.com/uzaret/1375/edit

* **Compatible with jQuery Mobile 1.4+**

* **Please note:** this widget is called date not datepicker so when calling methods you must use $(element).date("method"); other then this all jquery ui functionality is the same and you can see jquery ui api for usage http://api.jqueryui.com/datepicker/
